/** Automatically generated file. DO NOT MODIFY */
package com.example.coolapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}